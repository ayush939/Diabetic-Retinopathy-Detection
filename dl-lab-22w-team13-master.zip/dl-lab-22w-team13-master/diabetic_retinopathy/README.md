# TeamXX
- Name (st180270) John Pravin Arockiasamy - "ViT Branch"
- Name (st176425) Ayush Mittal - "cnn" branch

# How to run the code
to do

# Results
to do
